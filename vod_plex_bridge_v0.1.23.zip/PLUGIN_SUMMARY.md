# VOD To Plex — Plugin Summary

> Plugin running inside Dispatcharr container on .94.
> History: [2026-07-09 archive](PLUGIN_SUMMARY_ARCHIVE_20260709.md) (v0.1.22 full feature
> detail, v0.1.21 Stop/Start Server fixes, v0.1.17-20) |
> [2026-07-08 archive](PLUGIN_SUMMARY_ARCHIVE_20260708.md) |
> [2026-06-30 archive](PLUGIN_SUMMARY_ARCHIVE_20260630.md) | [pre-v0.1.3 archive](PLUGIN_SUMMARY_ARCHIVE_20260629.md)

## Deploy Process — Follow Every Step, Every Time

1. Read password into a shell var, never print it: `$lines = Get-Content "B:\Claude_Apps\.ssh.env"; $env:DISP_PASS = ($lines[3] -split '=',2)[1]`
2. `pscp` each changed file to `.94:/tmp/` individually — one command per file.
3. `docker cp` each file from `/tmp/` into the container — one `plink` call per file, not batched
   (a batched call with a stray BOM once silently broke only the first command). Chain
   `docker cp && chown 1000:1000 && echo COPY_OK` and check for `COPY_OK` in every call's output.
4. Clear `__pycache__`: `docker exec dispatcharr-IPTV2-94 find /data/plugins/vod_plex_bridge/ -name __pycache__ -exec rm -rf {} +`
5. **Verify with md5sum** — container vs. local for every changed file. All hashes must match
   before proceeding. Skipping this step let a silent partial-deploy failure go uncaught for
   several turns on 2026-07-08 (`plugin.py`).
6. Tell the user a Portainer restart is required — do not restart the container yourself
   (`sys.modules` caches old code; container lifecycle goes through Portainer only per CLAUDE.md).
7. After the user confirms restart, verify the fix behaves as expected before considering it done.

## Current State (2026-07-09, latest release: v0.1.22)

- **v0.1.22 is current and fully reconciled** — git (tagged `v0.1.22`), GitHub Release
  (zip asset, marked Latest), and `.94` all match. Bundles: connection gating (falls
  through to another provider account if the preferred one is at capacity), auto
  stream refresh + on-demand Refresh/Reactivate actions, named activity logging
  (movie titles + provider account in log lines and Maintenance Activity panel), and
  toast/spinner feedback on dashboard action buttons. Deployed, user-tested, confirmed
  working. Full detail in the 2026-07-09 archive.
- This release also closed out two carry-over items: the previously-uncommitted
  connection-gating diff, and the v0.1.19/v0.1.20 git reconciliation gap — both are
  now folded into the v0.1.22 commit history.

## Dispatcharr Channel Maintenance (not plugin code — tracked here since it's Dispatcharr-adjacent)
- **"Channel Fix"** — a global Claude Code skill (`~/.claude/skills/channel-fix/SKILL.md`) that
  alphabetizes and renumbers the user's 4 real Dispatcharr channel groups (Niko TV, 24/7, Live TV,
  Movies — ~157 channels total) and strips noisy `USA `/`UK: `/`US: ` name prefixes from Live TV
  and Movies (24/7's `24/7 ` prefix is meaningful, left alone). Invoke by saying "channel fix" in
  any session — not project-scoped, works everywhere.
- Manual/on-demand only via the `ecm` + `dispatcharr-94` MCP servers — ECM has no scheduler hook
  for arbitrary maintenance tasks. First run: 2026-07-08/09. See skill file for full procedure.

## Architecture
```
Plex hits STRM → rclone GET /vod/{id}.mkv
  → plugin: GET → 302 to {dispatcharr_url}/proxy/vod/movie/{uuid}?stream_id={id}
  → Dispatcharr proxy handles everything natively
```
No pre-fetching, no caching, no session resolution in the plugin — by design.

## Key Files
```
plugin/vod-plex-bridge/
├── bridge.py       — ORM queries, activation, STRM gen, language detection (NO cache/session code)
├── server.py       — WSGI routing, all API endpoints
├── plugin.py       — Plugin lifecycle, server start/stop/status
├── plugin.json     — Manifest (fields, actions)
└── templates/dashboard.html — Browse/Streams/Health UI
```
- Repo: `https://github.com/knmplace/dispatcharr-vod-plex-bridge-plugin`
- Container: `dispatcharr-IPTV2-94` | Port: 8888 | Dashboard: `http://192.168.1.94:8888/`
- Server start is MANUAL — click "Start Server" after enabling the plugin

## Pending
1. **EPG brown channels on .94** — assignments exist in DB, sources healthy, program records may
   be stale. Next: check EPG program records for those epg_data_ids, or force re-import.
2. Submit to official Dispatcharr plugin repo when stable.
3. Series support (after movies stable) — **ON HOLD**: Plex probes during library scan trigger
   real provider connections for episodes same as movies, unresolved.
4. **DO NOT re-add** head/tail cache, session pre-resolution, or a per-request liveness probe —
   all three tried and reverted (v0.1.6, v0.1.7, v0.1.9), all caused connection-holding or
   provider-churn problems. Any fast-start/failover idea must not add a plugin-side HTTP call
   on the hot path (rclone calls `get_redirect_url()` fresh on every Range/seek request).

## rclone on .109 (plugin mount)
- **Service**: `rclone-vodplugin.service` → `/mnt/vod-plugin`
- **Remote**: `vodplugin` → `http://192.168.1.94:8888/vod/`
- **Flags**: `--allow-other --read-only --vfs-cache-mode off --dir-cache-time 1m --poll-interval 0`
- **DO NOT add** `--vfs-read-chunk-size` or `--vfs-cache-mode full` — these hold connections open
