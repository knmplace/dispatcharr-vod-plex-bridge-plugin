# Series Support — Implementation Plan (DRAFT, not yet approved for build)

> Status: **research + design only**. No code has been written for this feature.
> User explicitly requested research-only, then asked for this plan to be written down
> so it can be picked back up in a future session. Do not start implementation without
> an explicit go-ahead.

## 1. Why this plan exists

Movies activate one file at a time — one STRM, one Plex scan-probe, one provider
connection. A TV series is not safe to activate the same way: a long-running show can
have 20+ seasons and 60-70 episodes per season (user's own example, "M*A*S*H"-style
show from the 1970s). Activating an entire series at once would generate hundreds of
STRM files simultaneously, and Plex issues a HEAD + Range probe against every file it
discovers during a library scan — the same mechanism that made bulk STRM generation
unsafe for movies before activation-gating was added. Doing this for a whole series
would fire a probe storm across however many provider accounts those episodes map to,
far beyond anything movies ever risked.

The fix the user proposed (2026-07-06): don't activate at the series level at all.
Activate at the **season** and/or **episode** level, with multi-select / "select all"
at each layer. This caps blast radius to exactly what the user actually wants to
watch, and reuses the exact same activation-gating principle that already makes movies
safe — it just needs a selection UI with more than one layer.

## 2. Confirmed data shapes (live-verified via Dispatcharr MCP, 2026-07-05/06)

- **Series** object: near-identical shape to `Movie` — `id`, `uuid`, `name`,
  `description`, `year`, `rating`, `genre`, `tmdb_id`, `imdb_id`, `logo`,
  `episode_count`, `custom_properties` (`cast`, `youtube_trailer`, `category_id`,
  `episode_run_time`, `backdrop_path`, `releaseDate`, `backdrop_path`).
- **Episode** object: `id`, `series` (FK back), `uuid`, `name`, `description`,
  `air_date`, `rating`, `duration_secs`, `season_number`, `episode_number`,
  `tmdb_id`, `imdb_id`, `custom_properties`, `providers` (array).
- **`Episode.providers`**: array of `{id, stream_id, container_extension,
  m3u_account: {...}}` — this is the per-episode equivalent of
  `movie.m3u_relations`, confirming multi-provider-per-episode is already modeled,
  same as movies.
- **No separate "Season" object exists in Dispatcharr.** Seasons are not a queryable
  entity — they only exist as the `season_number` field on each `Episode`. The plugin
  will need to derive season groupings client-side (or server-side in `bridge.py`) by
  grouping a series' episode list by `season_number`. This is a UI/aggregation
  concept only, not a new backend model to sync against.

## 3. Proposed data/selection model

Three-layer hierarchy, all UI-side on top of existing Series/Episode data:

```
Series (top layer — one row per show, from GET /api/vod/series/)
  └─ Season (derived, group Episodes by season_number; "All" checkbox per season)
       └─ Episode (leaf — actual activation unit; "All" checkbox per season = union)
```

- Checking "All" on a season selects every episode in that season.
- Checking/unchecking an individual episode should roll the season checkbox into a
  tri-state (all / none / partial) — same UX pattern as a typical file-tree picker.
- Activation payload becomes a list of episode IDs (not series IDs) — this is the
  actual unit that maps to `M3UMovieRelation`-equivalent provider streams and gets a
  STRM file. Series-level "activate everything" is still technically possible (select
  all seasons → all episodes) but is a user choice, not something the UI defaults to
  or makes into a single one-click action, precisely to avoid the automatic disaster
  case (2076-episode 1970s show scenario) becoming the easy path.

## 4. Mobile / small-screen constraint (new consideration, this session)

User flagged that some of this UI needs to work on a phone, not just desktop — this
changes the multi-layer picker design meaningfully:

- **A 3-level nested tree with checkboxes (desktop file-picker style) does not
  translate well to a phone screen.** Deep nesting + small tap targets is the
  classic mobile UX failure mode.
- **Better mobile-friendly pattern: drill-down navigation instead of nested
  expand/collapse.** Tap a Series card → navigate to a full-screen Seasons list for
  that series (like the existing Movies grid, one screen) → tap a Season → navigate
  to a full-screen Episodes list for that season with checkboxes + "Select All" /
  "Clear All" (reusing the exact same selection-bar pattern already built for the
  Movies grid) → "Activate Selected" button at the bottom, same as movies today.
  Back button returns to Seasons, then to Series.
- This means: **no new interaction pattern needs to be invented.** It's the existing
  Movies-tab list/select/activate pattern, applied recursively at two additional
  navigation depths (Series list → Season list → Episode list), rather than one flat
  grid. Desktop can still show it as a flat page-per-level (no need for true
  expand/collapse accordions), which keeps mobile and desktop using the *same* markup
  and behavior instead of a responsive fork — simpler to build and test once.
- Practical implication for the Series tab UI (replacing the tab-bar idea from the
  prior design pass): the "Series" tab click doesn't show an episode grid directly —
  it shows a Series grid (reusing the Movies grid card/pagination/search-filter
  pattern verbatim, just Series data). Selecting a series pushes into a Season view;
  selecting a season pushes into an Episode view. Only the Episode view has
  activate/deactivate actions and checkboxes. This keeps each screen simple and
  finger-friendly instead of trying to cram three nested selection layers onto one
  page.

## 5. What reuses existing patterns unchanged

Confirmed via the Series/Episode shape check above — no new logic needed for:
- TMDB metadata display (poster, description, genre, year, rating, cast)
- YouTube trailer embed (`custom_properties.youtube_trailer`, same field name as Movie)
- Language detection (operates on name/description text, same as movies)
- Category/provider filtering (Series has `category_id` in `custom_properties`,
  same shape as Movie's category FK conceptually; providers come from
  `episode.providers[].m3u_account`, same shape as `movie.m3u_relations`)

## 6. What needs new code (when this is actually built)

1. `bridge.py`: `list_series()`, `list_seasons(series_id)` (derived/grouped, not a
   direct Dispatcharr endpoint), `list_episodes(series_id, season_number)`,
   `activate_episodes(episode_ids)` / `deactivate_episodes(episode_ids)` — mirroring
   `list_movies` / `activate_movies` / `deactivate_movies` shape.
2. `server.py`: new routes — `/api/series`, `/api/series/{id}/seasons`,
   `/api/series/{id}/episodes?season=N`, `/api/episodes/activate`,
   `/api/episodes/deactivate`. Same JSON response conventions as existing movie routes.
3. STRM generation: needs an episode-aware filename/folder convention distinct from
   movies (e.g. `Series Name (Year)/Season 01/Series Name - S01E01 - Episode Title.strm`)
   so Plex's TV library scanner recognizes season/episode structure correctly — this
   is a Plex-side naming convention requirement, not just a bridge implementation
   detail, and needs to be gotten right before the first real activation test.
4. `dashboard.html`: Series grid view (reuse Movies grid markup/CSS), Season list view,
   Episode list view with checkboxes + Select All/Clear All/Activate/Deactivate bar
   (reuse Movies panel-header markup), simple back/breadcrumb navigation between the
   three views.
5. Selection-gating safety check: before allowing "Select All" at the season level to
   cascade, consider whether a max-episodes-per-activation warning/confirmation is
   worth adding (e.g. activating 70 episodes from one season at once is still a much
   bigger probe burst than a single movie) — flagged as an open question, not decided.

## 7. Open questions / decisions still needed before build starts

- Exact STRM/folder naming convention Plex expects for TV libraries (needs a quick
  live check against Plex's own naming spec, not yet done).
- Whether "Select All" at the season (or series) level should have any built-in
  batch-size warning/confirmation, given a big activation still means many
  simultaneous STRM files and provider probes at once — smaller than "whole series"
  but potentially still large for long-running shows.
- Whether per-episode multi-provider fallback (the `episode.providers` array) should
  be wired up now that the plugin has a real array of providers to pick from, or left
  as future work mirroring the still-not-built movie-side failover
  (`mark_stream_bad()` is dead code today, per prior investigation this session).
- Final tab/navigation naming and whether the previously-discussed "sticky header"
  UI request (deferred separately, unrelated to series) interacts at all with the new
  Series/Season/Episode navigation depth — probably not, but worth a glance when both
  are being built.

## 8. Explicit constraints carried over from prior research (still binding)

- **DO NOT** re-add any plugin-side HTTP pre-flight/probe/cache on the hot path
  (rclone calls the redirect endpoint fresh on every Range/seek request — this
  applies identically to episodes once they're activated, not just movies).
- **DO NOT** implement bulk "activate whole series" as a one-click default — the
  season/episode selection model above exists specifically to prevent that.
- No code changes until the user explicitly approves moving from plan to build.
