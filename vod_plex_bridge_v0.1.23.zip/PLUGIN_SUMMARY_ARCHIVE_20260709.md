# Archive — 2026-07-09 (superseded from PLUGIN_SUMMARY.md)

## v0.1.21 (2026-07-08) — Stop Server + Start Server race fixes
- **Stop Server didn't actually stop the HTTP server**: root cause was Celery worker
  autoscale landing action clicks in a different process than the one running the
  server, so `_server_instance` tracking missed it. Fixed via a loopback
  `POST /api/shutdown` endpoint so any process can ask the real owning process to
  shut down.
- **Start Server race**: concurrent clicks could both see the port as free and
  double-bind, thrown as spurious "port in use". Fixed by splitting bind
  (synchronous, under lock) from serve (background thread).
- Both live on .94 and released as Latest on GitHub as of that date.

## v0.1.19/v0.1.20 reconciliation (resolved by v0.1.22)
v0.1.20's auto-start-on-boot removal and cleanup-interval-setting work was deployed
to .94 and in the GitHub release zip but not committed/tagged in git at the time.
This — along with the previously-uncommitted connection-gating diff — was folded
into the single v0.1.22 commit/tag/release on 2026-07-09, closing out the gap.

## v0.1.17 (2026-07-07)
Replaced the dead Active-Streams/Proxy-Logs panels with a real persisted activity
log (Now Playing / Logs tabs) and added real play-request logging. The two
follow-ups noted at the time — richer log detail (movie/account names, not just
counts) and stale cached-provider-pick invalidation — were both delivered in
v0.1.22 (named activity logging + auto stream refresh / Reactivate action).

## Resolved items carried forward from earlier archives (no longer relevant to re-litigate)
- **Error screens** (MP4s for dead/busy/removed streams) — re-scoped as not needed;
  resolved by the stall-watchdog approach instead.
- **Provider fallback** — re-scoped as not needed as a separate feature;
  `mark_stream_bad()` is exercised automatically by the stall watchdog
  (bridge.py:201), not via a dashboard trigger.
- **Active Streams panel** — re-scoped as not needed; deferred permanently,
  architecturally hard given the 302-redirect design.
- **Dead-feed detection** — implementation done (stall watchdog advances the cached
  pick on a confirmed stall); was under user-testing as of 2026-07-08, since
  confirmed working with no further issues raised.

## v0.1.22 (2026-07-09) — full feature list
See PLUGIN_SUMMARY.md "Current State" for the short version. Full breakdown:
1. **Connection gating** — `get_redirect_url()` checks Dispatcharr's live Redis-backed
   connection pool (`apps.m3u.connection_pool.pool_has_capacity_for_profile`) before
   picking a provider, falling through to another `M3UMovieRelation` if the preferred
   account is at `max_streams` capacity (`_account_has_capacity`,
   `_pick_relation_with_capacity`, bridge.py).
2. **Auto stream refresh** — background scheduled task periodically clears cached
   provider picks for activated movies (configurable via new
   `stream_refresh_interval_days` setting, default 7, 0 disables) so the next play
   re-resolves fresh; skips movies currently playing
   (`_auto_refresh_stream_picks`, `_refresh_stream_pick`, `_currently_playing_movie_ids`).
3. **Manual Refresh + Reactivate actions** — new `/api/movies/refresh` and
   `/api/movies/reactivate` endpoints, both single-movie and bulk-select, for
   on-demand fixes to stuck/dead streams.
4. **Named activity logging** — activate/deactivate/refresh/reactivate/cleanup log
   lines and the Maintenance Activity panel list actual movie titles instead of bare
   counts (`_movie_names`); play-request logs show which provider account served the
   stream (`_account_name`, threaded through `log_play_request`).
5. **Toast + spinner UX** — dashboard buttons show a brief spinner while a request is
   in flight, then a toast confirming the result, so results are visible without
   checking the Logs tab.
6. Deployed to .94, tested and confirmed working by user; committed as `50232c6`
   (code) + `18e4b8d` (release zip), tagged and released as `v0.1.22` (Latest).
