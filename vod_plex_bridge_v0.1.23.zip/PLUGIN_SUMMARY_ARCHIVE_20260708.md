# Archive — detail moved out of PLUGIN_SUMMARY.md on 2026-07-08 to keep it ≤100 lines

See [PLUGIN_SUMMARY.md](PLUGIN_SUMMARY.md) for current state, deploy process, and pending list.
Older history also lives in [2026-06-30 archive](PLUGIN_SUMMARY_ARCHIVE_20260630.md) and
[pre-v0.1.3 archive](PLUGIN_SUMMARY_ARCHIVE_20260629.md).

## v0.1.21 — Stop Server cross-process shutdown fix (full detail)

External beta tester reported clicking Stop Server didn't actually stop the HTTP server
(dashboard stayed reachable after "Server stopped" was reported). Root-caused: Dispatcharr
runs Celery with worker autoscale (`--autoscale=6,1`, 1–6 dynamically spawned OS processes),
and plugin action clicks (Start/Stop/Status) run as Celery tasks that can land in a different
worker process each time. Each process has fully independent Python module state
(`_server_instance`/`_server_thread` in `plugin.py` are process-local globals), so a server
started in process A was invisible to process B's tracking — Stop Server in process B had
nothing to stop and silently reported success while the real server (in process A) kept
running. Killing the Celery worker process itself was ruled out as unsafe — that same process
also runs unrelated Celery tasks (DVR recordings, EPG, etc.), confirmed via `ps aux`.

- **Fix**: `server.py` — new `POST /api/shutdown` loopback HTTP endpoint + `BridgeServer.
  request_shutdown()`. Since the real server is already reachable from any process via loopback
  HTTP (same channel `_is_our_server()` already used to confirm liveness via `/api/ping`), any
  process can now ask the actual owning process's server to shut itself down over HTTP instead
  of trying to signal/kill a foreign OS process. The real `shutdown()` call is dispatched to a
  separate daemon thread from inside the `/api/shutdown` handler — calling it directly on the
  request-handler thread would deadlock, since `WSGIServer.shutdown()` blocks until
  `serve_forever()`'s loop (on a separate thread) notices and exits, which can't happen while
  that same thread is still busy handling the shutdown request itself.
- `plugin.py` — `_do_stop_server()` now detects the cross-process case (port bound, responds
  as our own plugin via `/api/ping`, but not tracked in this process's `_server_instance`) and
  calls the new `/api/shutdown` endpoint (`_request_remote_shutdown()`), polling up to 5s
  (20 × 0.25s) to confirm the port actually goes down before reporting success.
- `bridge.py` — `cleanup()` now joins the background stall-watchdog thread (bounded 15s wait,
  logs a warning if it doesn't exit in time) instead of only setting its stop `Event`, closing
  a window (up to ~15s) where the old watchdog could keep running/writing state after "Server
  stopped" was reported — a real but secondary bug found while investigating the main issue.
- **Verified live on .94** (2026-07-08): Dispatcharr restarted → Status correctly said "not
  running" → Start Server → dashboard reachable → Stop Server → "Server stopped" and dashboard
  immediately `ERR_CONNECTION_REFUSED` → confirmed clean restart cycle works.
- **Versioning note**: per explicit user instruction, this fix was folded into the existing
  `v0.1.21` release rather than cutting v0.1.22/23 as new public versions (those numbers were
  used transiently during same-day iteration/deploy-testing to .94 only, never committed to
  git). The `v0.1.21` git tag was force-moved to the new commit and the GitHub release's zip
  asset + notes were replaced to match. `.94`'s `plugin.json` was redeployed afterward so the
  dashboard footer correctly reads 0.1.21 again instead of the transient 0.1.23.
- Full deploy-runbook was used successfully three times in a row during this work (v0.1.22,
  v0.1.23 iterations, final v0.1.21 reconciliation) with zero silent failures.

## v0.1.21 — race condition in Start Server (earlier same day)

`server.py`'s `BridgeServer` split into `bind()` (synchronous socket bind, called while still
holding `_server_lock`) and `serve()` (runs `serve_forever()` on the background thread).
Previously the bind happened inside the thread target itself, after `BridgeCore.initialize()`'s
DB work — wide enough a window for a concurrent/rapid double Start-Server click to see the port
as free and attempt a duplicate bind, throwing spurious "port already in use" errors. Committed,
tagged, pushed, released as Latest on GitHub; confirmed already deployed/matching on .94 before
the release was cut.

## v0.1.19 / v0.1.20 reconciliation note

v0.1.19 reverted the v0.1.18 false-positive "liveness check failed" bug (removed HEAD pre-flight
probe from `get_redirect_url()` in `bridge.py`, back to a bare 302 redirect). Deployed to .94,
confirmed working via real Plex/Roku playback. Separately, auto-start-on-boot was removed from
`plugin.py`'s `start()` (was causing "port already in use" errors after container restarts
racing with manual Start Server clicks) — this fix plus a `plugin.json` bump to 0.1.20 were
deployed to .94 and baked into a replacement of the v0.1.19 GitHub release zip asset, but not
committed/tagged in git (user explicitly deferred reconciling this).

## v0.1.17 — configurable cleanup interval, replaced dead Streams/Logs features

- **Configurable removed-movie cleanup interval**: background watchdog for movies Dispatcharr
  has since dropped from its VOD catalog was hardcoded to run every 5 min; replaced with a
  time-based check reading new `removed_check_interval_secs` plugin setting (default 300s, min
  10s).
- **Removed "Active Streams"**: panel/tile were backed by hardcoded `0`/empty stubs, never
  implemented — architectural (once the plugin 302s, Dispatcharr's proxy handles transfer, so
  the plugin never sees per-stream bytes). Removed entirely. Streams tab renamed **"Now
  Playing"**, shows only the (working) Plex sessions panel.
- **Replaced "Proxy Logs" with a real activity log**: old tab called a route that never existed
  server-side (permanent 404). Built an in-memory ring buffer (`deque`, cap 500) recording
  activation/deactivation/cleanup-run events. Tab renamed **"Logs"**, backed by
  `GET`/`DELETE /api/activity-log`. Fixed a log-level filter bug (`""` for "All" never matched
  `'all'`).
- **Activity log persists across restarts**: loads/saves to `/data/vod-plex-bridge/activity_log.json`.
- **Added real play-request logging**: `/vod/` 302 handler in `server.py` logs every GET-triggered
  play request (movie name, IP, success/failure reason). HEAD requests (Plex metadata probes)
  excluded from logging.
- **Known follow-up, not addressed**: `get_redirect_url()` caches the resolved provider pick per
  movie indefinitely; only the stall watchdog or manual reactivate clears it. No fix attempted —
  needs design discussion on re-validating picks without adding per-request liveness probe
  (rejected once already in v0.1.10 for adding provider churn).

## Previous State (2026-07-06) — v0.1.12 dashboard UI fixes

Catalog Summary "Refresh" button wrapped in try/catch with "Refreshing…" state and visible error
on failure. Movie posters retry twice with backoff (`posterRetry()`) before "No Poster" fallback.
Browse tab's Catalog Summary + Movies filter bar wrapped in `.browse-pinned` with
`position: sticky`, offset via JS-computed `--header-h`/`--tabs-h` CSS vars. Added
`apple-touch-icon`, `shortcut icon`, PWA meta tags pointing at existing `/logo.png` (favicon
route was already correct/200 — globe-icon symptom was browser favicon caching, not a missing
asset).

## Previous State (2026-07-04/05)

- **v0.1.10 — simplified `get_redirect_url()`, no probe/retry**: after a failed v0.1.9 experiment
  (per-request liveness probe made provider churn worse — see 2026-06-30 archive), reverted to
  simplest design: pick `movie.m3u_relations.first()` (or cached `stream_pick`), bare 302, let
  Dispatcharr/rclone handle session/retry natively.
- **Root-caused (not fixed, doesn't need to be)**: intermittent "No suitable M3U profile found"
  traced to M3U accounts with a real provider-side 1-connection limit; a brief self-resolving
  overlap at playback start (rclone `--vfs-cache-mode off`) collides on those accounts only.
  Raising `max_streams` rejected (provider's real limit is 1 regardless); switching to
  `--vfs-cache-mode full` rejected as disproportionate. Accepted provider limitation, not a bug.
- Consistent 3-tuple return from every `get_redirect_url()` branch (latent bug fixed in passing).
- `server.py` WSGI wrapper hardened: top-level try/except logs unhandled exceptions, returns 500.
- Favicon added (`/favicon.ico`, `/logo.png`, `<link rel="icon">`) — cosmetic only.

## Previous State (2026-07-02)

- **`/api/headcache/status` mystery 404s — SOLVED, self-inflicted, no code issue**: root cause was
  three of Claude's own orphaned background bash polling loops from earlier in the session, never
  killed after use. Killed all six leftover processes; confirmed silent afterward. Debug logging
  (`UNMATCHED_ROUTE` warning in `server.py`'s 404 fallthrough) was added during the investigation
  and intentionally left in place.
  - Stop Server dashboard button was broken/no-op at the time — **fixed in v0.1.21, 2026-07-08**.
- **Confirmed healthy**: `get_vod_proxy_stats` (0 active connections, no leaks), `get_system_events`
  showed clean `vod_start`/`vod_stop` pairs, zero `vod_error`. Playback stable, no held connections.
- **VOD2MLIB investigation — concluded, no merge**: considered merging with R3XCHRIS/VOD2MLIB for
  Plex support; rejected because it bulk-generates .strm for the entire catalog by default, which
  would trigger real provider connections during Plex library scan (same root cause as the shelved
  series-support issue). Decision: keep plugins fully independent, two separate rclone mounts.
- Version snapshot: v0.1.8 (stripped head/tail cache + session pre-resolution) — superseded by
  v0.1.10.

## What's in v0.1.8

**Problem fixed**: plugin was holding provider connections open after playback stopped.
1. `rclone-vodplugin.service` had `--vfs-read-chunk-size` flags causing sequential range requests
   that kept connections open. Removed.
2. `bridge.py` had head/tail cache + session pre-resolution machinery (added v0.1.7, mistakenly
   mirroring the standalone bridge). Stripped entirely — Dispatcharr's 302 redirect handles
   persistent connections, Range requests, and session management natively.

## To-do detail: richer activity-log detail (raised 2026-07-07)

1. Activate log line should include movie name(s) + provider/M3U account name, not just a count
   (`activate_movies()` in bridge.py).
2. Play-request log line already has the M3U account id available (`get_redirect_url()` returns
   `account_id` but `server.py:218`'s call to `log_play_request()` drops it) — thread it through
   and resolve to the account's display name in the log line.
3. Deactivate log line shows "removed 0 from Plex" too often with no explanation.
   `_plex_delete_movies()` matches Plex items to movie IDs via filename regex against Plex's
   `/library/sections/{id}/all` response — silently finds nothing if Plex hasn't scanned the item
   yet, or the rclone path doesn't preserve that filename pattern. Need: (a) log deactivated movie
   names not just a count, (b) a distinct warning log line for "no matching Plex item found" vs.
   "found but delete request failed."

## To-do detail: dead-feed detection too slow (raised 2026-07-07)

User observed a play request that should have been ~7 seconds of actual content instead hammer
"redirect OK" repeatedly for ~4.5-5 minutes against a provider stream that was actually dead.
Root cause, per current code: there is no pre-flight liveness check at all today (removed in
v0.1.19 — a HEAD request can't detect mid-stream stalls anyway). The only defense is the stall
watchdog (`_check_for_stalls()`, `STALL_THRESHOLD_SECS = 25`, polled every 10s off Plex's own
session API), which only fires if Plex reports a session stuck in `state == "buffering"` at an
unchanging `view_offset` for 25 straight seconds — and even then won't switch providers again for
the same movie within `STALL_COOLDOWN_SECS = 600` (10 min). Meanwhile every Plex retry against
`/vod/{id}.mkv` calls `get_redirect_url()` again, which just returns the same cached `stream_pick`
and logs "redirect OK" each time. Needs a design session on: (a) why Plex wasn't staying in a
stable "buffering" state long enough to trip the 25s threshold, (b) whether the cooldown is too
long for a feed dead from the very first request, (c) whether some cheap real signal (opening the
Dispatcharr proxy connection and checking for real byte throughput before 302'ing, without
reintroducing the v0.1.18 false-positive problem) could catch a dead feed in 1-2 attempts instead
of ~5 minutes. Not yet implemented — needs investigation, not just a quick fix.
